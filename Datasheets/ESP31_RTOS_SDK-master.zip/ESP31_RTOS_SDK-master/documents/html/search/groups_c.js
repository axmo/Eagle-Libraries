var searchData=
[
  ['wifi_20related_20apis',['WiFi Related APIs',['../group___wi_fi___a_p_is.html',1,'']]],
  ['wps_20apis',['WPS APIs',['../group___w_p_s___a_p_is.html',1,'']]]
];
