var searchData=
[
  ['offer_5fend',['OFFER_END',['../group___misc___a_p_is.html#gga47797d528afd74db93dd37a2c9207333ab67ba95f9dcf33d1cd600d798c76ab88',1,'esp_misc.h']]],
  ['offer_5frouter',['OFFER_ROUTER',['../group___misc___a_p_is.html#gga47797d528afd74db93dd37a2c9207333ad88e6ec93eb09e1cccb8d4d039681f42',1,'esp_misc.h']]],
  ['offer_5fstart',['OFFER_START',['../group___misc___a_p_is.html#gga47797d528afd74db93dd37a2c9207333a8d64153b2be4f126695bb7f6d36cff2c',1,'esp_misc.h']]],
  ['old_5fmode',['old_mode',['../struct_event___sta_mode___auth_mode___change__t.html#aec107fd7e68f2881586ebd4c9d1df031',1,'Event_StaMode_AuthMode_Change_t']]],
  ['os_5ftimer_5farm',['os_timer_arm',['../group___timer___a_p_is.html#ga26366c1af6634ad1bac5579c3cbe301d',1,'esp_timer.h']]],
  ['os_5ftimer_5fdisarm',['os_timer_disarm',['../group___timer___a_p_is.html#gae5d5bc766def32d5dbba2bb44e02fd00',1,'esp_timer.h']]],
  ['os_5ftimer_5fsetfn',['os_timer_setfn',['../group___timer___a_p_is.html#ga77b22f92e381327c7d717ab408df9967',1,'esp_timer.h']]],
  ['ota_5ferror_5fid',['ota_error_id',['../group__system__upgrade___a_p_is.html#ga1e8876da5916ec8c91b126453fad76f9',1,'upgrade.h']]],
  ['ota_20apis',['OTA APIs',['../group__system__upgrade___a_p_is.html',1,'']]]
];
