var searchData=
[
  ['phy_5f2nd_5fchan',['phy_2nd_chan',['../group___phy___a_p_is.html#ga30cff0e7c9305a1b35a1501d1ff12bd0',1,'esp_phy.h']]],
  ['phy_5fbw',['phy_bw',['../group___phy___a_p_is.html#ga61dc658779b25a414891511d83a09994',1,'esp_phy.h']]],
  ['phy_5fmode',['phy_mode',['../group___phy___a_p_is.html#gac7b011149ade6368aa9194808621eb7e',1,'esp_phy.h']]]
];
