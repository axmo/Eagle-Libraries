var searchData=
[
  ['tentative',['TENTATIVE',['../group__system__upgrade___a_p_is.html#ggadf764cbdea00d65edcd07bb9953ad2b7a661b0215f708ebf8454810da5c4fe2e5',1,'upgrade.h']]]
];
