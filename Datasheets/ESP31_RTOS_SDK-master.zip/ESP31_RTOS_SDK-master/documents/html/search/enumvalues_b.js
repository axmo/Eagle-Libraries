var searchData=
[
  ['ready',['READY',['../group__system__upgrade___a_p_is.html#ggadf764cbdea00d65edcd07bb9953ad2b7a6564f2f3e15be06b670547bbcaaf0798',1,'upgrade.h']]],
  ['recv_5fdata_5ferror',['RECV_DATA_ERROR',['../group__system__upgrade___a_p_is.html#gga1e8876da5916ec8c91b126453fad76f9aadecbeb60728ebaba4cb52ce20e83eb7',1,'upgrade.h']]]
];
