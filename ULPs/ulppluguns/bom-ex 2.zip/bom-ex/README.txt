Copy the ULP's within this directory to your Eagle ULP directory or other ULP directory specified in your Eagle directory path configuration. The BOM-EX documentation describes the basic information for usage of the ULP's contained in this package. 

A complete sample project that demonstrates the use of the BOM-EX package is also provided. Copy the sample MicroRC project to your Eagle project directory, load the schematic/board file and execute the bom-ex.ulp to view a complete BOM listing. After the BOM viewer loads and the database is successfully loaded, you can then export various BOM part order files or save a BOM report file.

The latest version of this package is also available at http://www.bobstarr.net

//////////////////////////////////////////////////////////////////////////
// N O T E S
//////////////////////////////////////////////////////////////////////////

THE DATBASE COLUMN HEADER NAMES HAVE CHANGED SINCE v1.14!

YOU MUST UPDATE YOUR DATABASE COLUMN HEADER NAMES IF YOU ARE UPGRADING FROM A PREVIOUS RELEASE OF BOM-EX PRIOR TO v1.14. FAILURE TO UPDATE THE COLUMN NAMES WILL CAUSE THE ORDER EXPORT OPERATIONS TO FAIL, GENERATE INCORRECT ERRORS AND/OR INCORRECT INFORMATION.





