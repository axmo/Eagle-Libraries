# SnapEDA-eagle-plugin
The instructions for installing the  SnapEDA Plugin for EAGLE (Alpha) are as follows:

1. Upon launching Eagle, you’ll see the Control Panel. Open Scripts > Eagle.scr and add the following line to the MENU area in both the BRD and SCH sections:
‘[snapeda.png] SnapEDA : Run snapeda.ulp;’\
2. In the Eagle application directory, open the ulp folder and save the snapeda.ulp file there
3. In the ulp folder, also save the json.inc file
4. In the bin folder, save the snapeda.png